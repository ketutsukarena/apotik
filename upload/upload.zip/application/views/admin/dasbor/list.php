<table class="table table-striped  table-hover">
    <tbody>
        <tr class="odd gradeX">
            <td>
                <a href="<?php echo base_url('admin/user') ?>">
                    <table>
                        <tr align="center">
                            <td><i class="fa fa-user fa-5x"/></td>
                        </tr>
                        <tr align="center">
                            <td>Kelola User</td>
                        </tr>
                    </table>
                </a>
            </td>
            <td>
                <a href="<?php echo base_url('admin/suplier') ?>">
                    <table>
                        <tr align="center">
                            <td><i class="fa fa-heart fa-5x"/></td>
                        </tr>
                        <tr align="center">
                            <td>Kelola Data Suplier</td>
                        </tr>
                    </table>
                </a>
            </td>   
            <td>
                <a href="<?php echo base_url('admin/obat') ?>">
                    <table>
                        <tr align="center">
                            <td><i class="fa fa-flask fa-5x"/></td>
                        </tr>
                        <tr align="center">
                            <td>Kelola Data Obat
                        </tr>
                    </table>
                </a>
            </td>
            <td>
                <a href="<?php echo base_url('admin/jenis') ?>">
                    <table>
                        <tr align="center">
                            <td><i class="fa fa-list fa-5x"/></td>
                        </tr>
                        <tr align="center">
                            <td>Kelola Jenis Obat
                        </tr>
                    </table>
                </a>
            </td>
        </tr>
    </tbody>
</table>
