<?php 
// Ambil data isi dari controller
	if ($isi) {
		$this->load->view($isi);
	}
?>