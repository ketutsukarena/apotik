<table class="table table-striped  table-hover">
    <tbody>
        <tr class="odd gradeX">
            <td>
                <a href="<?php echo base_url('kasir/dasbor/profile') ?>">
                    <table>
                        <tr align="center">
                            <td><i class="fa fa-user fa-5x"/></td>
                        </tr>
                        <tr align="center">
                            <td>My Profile</td>
                        </tr>
                    </table>
                </a>
            </td>
            <td>
                <a href="<?php echo base_url('admin/obat') ?>">
                    <table>
                        <tr align="center">
                            <td><i class="fa fa-flask fa-5x"/></td>
                        </tr>
                        <tr align="center">
                            <td>Data Obat
                        </tr>
                    </table>
                </a>
            </td>
            <td>
                <a href="<?php echo base_url('kasir/penjualan/transaksi') ?>">
                    <table>
                        <tr align="center">
                            <td><i class="fa fa-list fa-5x"/></td>
                        </tr>
                        <tr align="center">
                            <td>Mulai Transaksi
                        </tr>
                    </table>
                </a>
            </td>
        </tr>
    </tbody>
</table>
